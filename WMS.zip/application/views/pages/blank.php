<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        -
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                        <li class="active">-</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                </section> <!--&lt;!&ndash; /.content &ndash;&gt;-->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

